#ifndef DEFS_HPP
#define DEFS_HPP

#define ALPHABET_SIZE 6
#define NUMBER_OF_STATES 9

#endif